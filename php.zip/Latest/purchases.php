<?php 
session_start(); 

if (!isset($_SESSION['username'])) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['username']);
	header("location: login.php");
}
$username = $_SESSION['username'];
include "dbConn.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Purchases</title>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="style.css?v=<?php echo time();?>">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script>
		$( function() {
			$( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
		} );
	</script>
</head>
<body>
<?php include 'header.php'; ?>
	<div class="header">
		<h2>Purchases</h2>
	</div>
	<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
					echo $_SESSION['success']; 
					unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>

		<!-- logged in user information -->
		<?php  if (isset($_SESSION['username'])) : ?>
			<h2>Welcome <strong><?php echo $_SESSION['username']; ?></strong></h2>
			<h3>Your Purchases</h3>
			<form method="get" action="">
				<label>Show purchases made on this date or later: </label>
				<input type="text" name="purchase_date" id="datepicker" value="<?php if(isset($_GET['purchase_date'])) echo $_GET['purchase_date'];?>">
				<input type="submit" value="Search" class="btn">
			</form>


			<?php 
			if(isset($_GET['purchase_date'])){
				if($_GET['purchase_date'] == ''){

				}
				else{
					$date = $_GET['purchase_date'];
					$date = strtotime($date);
					// echo $date;
					$records = mysqli_query($db1, "SELECT * From purchases INNER JOIN customers ON purchases.user_id = customers.username where user_id='".$username."' AND `time` >= '".$date."'"); 
					if(mysqli_num_rows($records) > 0){
						// $data = mysqli_fetch_assoc($records);
						// print_r($data);
						?>
						<table class="purchases">
							<thead>
								<tr>
									<th>Delete</th>
									<th>Product Code</th>
									<th>First Name</th>
									<th>Last Name</th>
									<th>City</th>
									<th>Comments</th>
									<th>Price</th>
									<th>Qty</th>
									<th>Subtotal</th>
									<th>Taxes</th>
									<th>Grand Total</th>
									<th>Date</th>
								</tr>
							</thead>
							<tbody>
								<?php
								while($value = mysqli_fetch_assoc($records)){
									echo '<tr>';
									echo "<td data-id='".$value['purchase_id']."'>Delete</td>";
									echo "<td>".$value['Productcode']."</td>";
									echo "<td>".$value['Firstname']."</td>";
									echo "<td>".$value['Lastname']."</td>";
									echo "<td>".$value['City']."</td>";
									echo "<td>".$value['Comments']."</td>";
									echo "<td>".$value['selling_price']."</td>";
									echo "<td>".$value['quantity_sold']."</td>";
									echo "<td>".$value['Subtotal']."</td>";
									echo "<td>".$value['Tax']."</td>";
									echo "<td>".$value['GrandTotal']."</td>";
									echo "<td>".$value['date']."</td>";
									echo '</tr>';
								}
								?>
							</tr>
						</tbody>
					</table>
					<?php
				}
				else{
					$records = mysqli_query($db1, "SELECT * From purchases INNER JOIN customers ON purchases.user_id = customers.username where user_id='".$username."'"); 
					if($db1->error){
						echo $db1->error;
					}
					if(mysqli_num_rows($records) > 0){
						?>
						<table class="purchases">
							<thead>
								<tr>
									<th>Delete</th>
									<th>Product Code</th>
									<th>First Name</th>
									<th>Last Name</th>
									<th>City</th>
									<th>Comments</th>
									<th>Price</th>
									<th>Qty</th>
									<th>Subtotal</th>
									<th>Taxes</th>
									<th>Grand Total</th>
									<th>Date</th>
								</tr>
							</thead>
							<tbody>
								<?php
								while($value = mysqli_fetch_assoc($records)){
									echo '<tr>';
									echo "<td data-id='".$value['purchase_id']."'>Delete</td>";
									echo "<td>".$value['Productcode']."</td>";
									echo "<td>".$value['Firstname']."</td>";
									echo "<td>".$value['Lastname']."</td>";
									echo "<td>".$value['City']."</td>";
									echo "<td>".$value['Comments']."</td>";
									echo "<td>".$value['selling_price']."</td>";
									echo "<td>".$value['quantity_sold']."</td>";
									echo "<td>".$value['Subtotal']."</td>";
									echo "<td>".$value['Tax']."</td>";
									echo "<td>".$value['GrandTotal']."</td>";
									echo "<td>".$value['date']."</td>";
									echo '</tr>';
								}
								?>
							</tr>
						</tbody>
					</table>
					<?php

				}
			}
		}
	}

	?>








	<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
<?php endif ?>
</div>

</body>
</html>