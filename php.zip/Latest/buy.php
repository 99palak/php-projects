<?php 
session_start(); 

if (!isset($_SESSION['username'])) {
 $_SESSION['msg'] = "You must log in first";
 header('location: login.php');
}
if (isset($_GET['logout'])) {
 session_destroy();
 unset($_SESSION['username']);
 header("location: login.php");
}
include "dbConn.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Buy</title>
	<link rel="stylesheet" type="text/css" href="style.css?v=<?php echo time();?>">
</head>
<body>
  <?php include 'header.php'; ?>
  <div class="header">
   <h2>Home Page</h2>
 </div>
 <div class="content">
   <!-- notification message -->
   <?php if (isset($_SESSION['success'])) : ?>
    <div class="error success" >
     <h3>
      <?php 
      echo $_SESSION['success']; 
      unset($_SESSION['success']);
      ?>
    </h3>
  </div>
<?php endif ?>

<!-- logged in user information -->
<?php  if (isset($_SESSION['username'])) : ?>
 <h2>Welcome <strong><?php echo $_SESSION['username']; ?></strong></h2>
 <h3>you can purchase anything</h3>



 <?php

 if(isset($_POST['purchase_item'])){
  // print_r($_POST);
  $tax = 15.2;
  $records = mysqli_query($db1, "SELECT productcode,description,price From products where productcode='".$_POST['productcode']."'");  // Use select query here 
  if(mysqli_num_rows($records) > 0){
    $data = mysqli_fetch_assoc($records);
    $price = $data['price'];
    $quantity = $_POST['quantity'];
    $comment = $_POST['comment'];
    $productcode = $_POST['productcode']; 
    $username = $_SESSION['username'];
    $subtotal = $price*$quantity;
    $taxtotal = number_format((float)$subtotal * ($tax/100), 2, '.', '');
    $grandtotal = $subtotal + $tax;

    $date = date('Y-m-d');
    $time = time();
    $purchase_id = time().rand(1,100);

  // echo '<br>';
  // echo $quantity."<br>";
  // echo $price."<br>";
  // echo $comment.'<br>';
  // echo $productcode.'<br>';
  // echo $username.'<br>';
  // echo $subtotal.'<br>';
  // echo $taxtotal.'<br>';
  // echo $grandtotal.'<br>';
  // echo date('Y-m-d').'<br>';
  // echo time();
    $query = "INSERT INTO purchases (quantity_sold, purchase_id,selling_price, comments, `date`,`time`,productcode,user_id,subtotal,tax,grandtotal ) 
    VALUES('$quantity', '$purchase_id','$price','$comment', '$date', '$time', '$productcode', '$username', '$subtotal', '$tax', '$grandtotal')";
    if(mysqli_query($db1, $query)){
      header('location: purchases.php?');
    }
    else{
      echo($db->error);
    }



    die();

  }
}
?>

<form method="post" action="" >

  <div class="input-group">
    <label>Product Code</label>
    <select name="productcode" required="" class="productcode">
      <option disabled value="" selected="">-- Select product --</option>
      <?php

        $records = mysqli_query($db1, "SELECT productcode,description,price From products");  // Use select query here 

        while($data = mysqli_fetch_array($records))
        {
            echo "<option value='". $data['productcode'] ."'>" .$data['description'] ." ($ " .$data['price']  ." ) "."</option>";  // displaying data in option menu

          } 
        // Mera phone band ho gya, anku nu kareo call
          ?>  
        </select>
      </div>




      <div class="input-group">
        <label>Comment</label>

        <input type="comment" name="comment" >
      </div>
      <div class="input-group">
        <label>Quantity</label>
        <input type="text" name="quantity" pattern="[1-9]?[0-9]" required="">
      </div>
      <div class="input-group">
        <button type="submit" class="btn" name="purchase_item">Register</button>
      </div>

    </form>

    <?php
    if (isset($_POST['purchase_item'])) {
    // receive all input values from the form
     include('dbConn.php'); 
     
     $value =$_POST['post_code'];
     $query = "select price from products where productcode=$value";
     $run = mysqli_query($db1, $query);
     while($row = mysqli_fetch_array($run))
     {
      $price = $row['price'];

    }


    $username=$_SESSION['username'];
    $post_code = mysqli_real_escape_string($db1, $_POST['post_code'] ?? null);
    $comment = mysqli_real_escape_string($db1, $_POST['comment']);
    $quantity = mysqli_real_escape_string($db1, $_POST['quantity']);
    


    $purchase = "INSERT INTO purchases (productcode,username, comment, quantity, price) 
    VALUES('$post_code', '$username', '$comment', '$quantity', '$price')";
    mysqli_query($db1, $purchase); 
  }
  ?>










  <p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
<?php endif ?>
</div>

</body>
</html>