<ul class="nav">
  <li><a class="active" href="index.php">Home</a></li>
  <li><a href="buy.php">Buy</a></li>
  <li><a href="purchases.php">Purchases</a></li>
  <li><a href="account.php">Account</a></li>
  <?php if (isset($_SESSION['username'])) { ?>
  <li style="float: right;"><a href="index.php?logout='1'" style="color: red;">Logout</a></li>
<?php } ?>
</ul>