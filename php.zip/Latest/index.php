<?php 
session_start(); 

if (!isset($_SESSION['username'])) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['username']);
	header("location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php include 'header.php'; ?>
	<div class="header">
		<h2>Home Page</h2>
	</div>
	<div class="content">

		<!-- logged in user information -->
		<?php  if (isset($_SESSION['username'])) : ?>
			<h2 >Welcome <strong><?php echo $_SESSION['username']; ?></strong></h2>
			<h3 style="margin-top: 20px;">Welcome to my website</h3>


		<?php endif ?>
	</div>

</body>
</html>