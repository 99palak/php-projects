<?php

$db1 = mysqli_connect("localhost","u588014632_project","Palak_project_1","u588014632_project");

if(!$db1)
{
    die("Connection failed: " . mysqli_connect_error());
}

?>