


<form method="post" action="" >

  	  	<div class="input-group">
  	  <label>Product Code</label>
        <select name="post_code">
    <option disabled selected>-- Select product --</option>
    <?php
        include "dbConn.php";  // Using database connection file here
        $records = mysqli_query($db1, "SELECT productcode,description,price From products");  // Use select query here 

        while($data = mysqli_fetch_array($records))
        {
            echo "<option value='". $data['productcode'] ."'>" .$data['description'] ." ($ " .$data['price']  ." ) "."</option>";  // displaying data in option menu

          }	
        // Mera phone band ho gya, anku nu kareo call
    ?>  
  </select>
  	</div>


   

  	<div class="input-group">
  	  <label>Comment</label>
      
  	  <input type="comment" name="comment" >
  	</div>
      <div class="input-group">
  	  <label>Quantity</label>
  	  <input type="quantity" name="quantity" >
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="purchase_item">Register</button>
  	</div>

</form>

<?php
if (isset($_POST['purchase_item'])) {
    // receive all input values from the form
     include('dbConn.php'); 
     
     $value =$_POST['post_code'];
     $query = "select price from products where productcode=$value";
     $run = mysqli_query($db1, $query);
    while($row = mysqli_fetch_array($run))
      {
        $price = $row['price'];
  
        }


    $username=$_SESSION['username'];
    $post_code = mysqli_real_escape_string($db1, $_POST['post_code'] ?? null);
    $comment = mysqli_real_escape_string($db1, $_POST['comment']);
    $quantity = mysqli_real_escape_string($db1, $_POST['quantity']);
    


    $purchase = "INSERT INTO purchases (productcode,username, comment, quantity, price) 
    VALUES('$post_code', '$username', '$comment', '$quantity', '$price')";
    mysqli_query($db1, $purchase); 
}
?>