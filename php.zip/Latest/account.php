<?php 
session_start(); 
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
if (!isset($_SESSION['username'])) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['username']);
	header("location: login.php");
}
$username = $_SESSION['username'];
$errors = array(); 
include "dbConn.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Account</title>
	<link rel="stylesheet" type="text/css" href="style.css?v=<?php echo time();?>">
</head>
<body>
<?php include 'header.php'; ?>
	<div class="header">
		<h2>Account</h2>
	</div>
	<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
					echo $_SESSION['success']; 
					unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>

		<!-- logged in user information -->
		<?php  if (isset($_SESSION['username'])) : ?>
			<h2>Welcome <strong><?php echo $_SESSION['username']; ?></strong></h2>
			<h3>Update your info</h3>
			<?php
			function updateInfo(){
				global $db1;
				$firstname = $_POST['firstname'];
				$lastname = $_POST['lastname'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				$postal = $_POST['postal'];
				$username = $_POST['username'];
				$oldusername = $_POST['old_username'];
				$password = $_POST['password'];
				$updateQuery = "UPDATE customers SET `Firstname`='".$firstname."', `Lastname`='$lastname', `Address`='$address', `City`='$city', `Postal_Code`='$postal', `username`='$username', `password`='".md5($password)."'  where `username`='".$oldusername."'";
				if(!mysqli_query($db1, $updateQuery)){
					echo $db1->error;
					// echo $updateQuery;
				}

			}
			if(isset($_POST['update'])){
				// print_r($_POST);
				if($_POST['old_username'] != $_POST['username']){
					$records = mysqli_query($db1, "SELECT * From customers where username='".$_POST['username']."'"); 
					if(mysqli_num_rows($records) > 0){
						array_push($errors, "Username already used!");
					}
					else{
						updateInfo();
					}
				}
				else{
					updateInfo();
				}
			}



			$records = mysqli_query($db1, "SELECT * From customers where username='".$username."'"); 
			if(mysqli_num_rows($records) > 0){
				$userInfo = mysqli_fetch_assoc($records);
				
				?>
				<form method="post" action="">
					<?php include('errors.php'); ?>
					<input type="hidden" name="old_username" value="<?php echo $userInfo['username'];?>">
					<div class="input-group">
						<label>Firstname: </label><input type="text" name="firstname" value="<?php echo $userInfo['Firstname'];?>" required>
					</div>
					<div class="input-group">
						<label>Lastname: </label><input type="text" name="lastname" value="<?php echo $userInfo['Lastname'];?>" required>
					</div>
					<div class="input-group">
						<label>Address: </label><input type="text" name="address" value="<?php echo $userInfo['Address'];?>" required>
					</div>
					<div class="input-group">
						<label>City: </label><input type="text" name="city" value="<?php echo $userInfo['City'];?>" required>
					</div>
					<div class="input-group">
						<label>Postal Code: </label><input type="text" name="postal" value="<?php echo $userInfo['Postal_Code'];?>" required>
					</div>
					<div class="input-group">
						<label>Username: </label><input type="text" name="username" value="<?php echo $userInfo['username'];?>" required>
					</div>
					<div class="input-group">
						<label>Password: </label><input type="password" name="password" value="" required>
					</div>
					<div class="input-group">
						<input type="submit" name="update" class="btn" value="Update Info">
					</div>

				</form>
				<?php
			}
			?>


			<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
		<?php endif ?>
	</div>

</body>
</html>